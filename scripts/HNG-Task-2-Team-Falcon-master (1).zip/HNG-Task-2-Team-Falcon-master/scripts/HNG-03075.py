print("Hello World, this is Muhammad Ibrahim with HNGi7 ID HNG-03075 using python for stage 2 task. muhammadib113@gmail.com")
